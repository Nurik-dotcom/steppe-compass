package com.example.kazakhstan_travel

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
