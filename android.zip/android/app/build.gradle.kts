import java.util.Properties
import java.io.FileInputStream

android {
    namespace = "com.example.kazakhstan_travel"
    compileSdk = flutter.compileSdkVersion

    defaultConfig {
        applicationId = "com.example.kazakhstan_travel"
        minSdk = 23
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        multiDexEnabled = true
    }

    // Java 17 рекомендую (можно оставить 11, если всё ок)
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // ── читаем key.properties
    val keystoreProps = Properties().apply {
        val f = rootProject.file("key.properties")
        if (f.exists()) {
            f.inputStream().use { load(it) }
        }
    }

    signingConfigs {
        create("release") {
            if (keystoreProps.isNotEmpty()) {
                storeFile = file(keystoreProps["storeFile"] as String)
                storePassword = keystoreProps["storePassword"] as String
                keyAlias = keystoreProps["keyAlias"] as String
                keyPassword = keystoreProps["keyPassword"] as String
            }
        }
    }
    buildTypes {
        getByName("debug") {
            // стандартный debug-ключ Android Studio
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("release") // ← ВАЖНО
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}
