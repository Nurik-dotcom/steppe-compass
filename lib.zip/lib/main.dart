// lib/main.dart
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

// Firebase
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'firebase_options.dart';

// Модели Hive
import 'models/user.dart';
import 'models/place.dart';
import 'models/region.dart';

// Сервисы/инициализация
import 'services/favorites_service.dart';
import 'services/likes_service.dart';
import 'services/auth_service.dart';
import 'services/json_import_service.dart';

// Экраны
import 'screens/root_shell.dart';
import 'screens/login_screen.dart';
import 'screens/direction_screen.dart';
import 'screens/user_profile_screen.dart';
import 'screens/admin_panel_screen.dart';
import 'screens/debug_data_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    if (Firebase.apps.isEmpty) {
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
    }
  } catch (e) {
    debugPrint('Firebase init skipped: $e');
  }

  // 3) Hive + сервисы
  await Hive.initFlutter();

  // Инициализация сервисов, которые используют Hive
  await FavoritesService.init();
  await LikesService.init();

  // Регистрация адаптеров (без падения на hot reload)
  try { Hive.registerAdapter(UserAdapter()); } catch (_) {}
  try { Hive.registerAdapter(PlaceAdapter()); } catch (_) {}
  try { Hive.registerAdapter(RegionAdapter()); } catch (_) {}

  // 4) Открываем боксы
  await Hive.openBox<User>('users');   // кэш профиля (оставили для совместимости UI)
  await Hive.openBox('session');       // кэш текущей "сессии" пользователя
  await Hive.openBox<Place>('places'); // данные
  await Hive.openBox<Region>('regions');

  // 5) Сидирование стартовых данных из assets при первом запуске
  final seeder = JsonSeedService();
  await seeder.seedIfNeeded(onLog: (m) => debugPrint(m));

  runApp(const KazakhstanTravelApp());
}

// (Опционально) Твоя старая утилита — оставил как есть
Future<void> ensureInitialAdmin() async {
  final users = Hive.box<User>('users');
  if (users.isEmpty) return;
  final anyAdmin = users.values.any((u) => u.isAdmin);
  if (anyAdmin) return;

  final first = users.values.first;
  first.isAdmin = true;
  await first.save();
}

class KazakhstanTravelApp extends StatelessWidget {
  const KazakhstanTravelApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kazakhstan Travel',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.teal),
      routes: {
        '/directions': (_) => const DirectionsScreen(),
        '/profile': (_) => const UserProfileScreen(),
        '/admin': (_) => const AdminPanelScreen(),
        '/debug': (_) => const DebugDataScreen(),
      },
      // Вместо FutureBuilder(getLoggedInUser) — слушаем Firebase auth
      home: const _AuthGate(),
    );
  }
}

/// AuthGate: ждём событие аутентификации и показываем нужный экран.
/// Если есть пользователь (включая анонимного) — RootShell, иначе — LoginScreen.
class _AuthGate extends StatelessWidget {
  const _AuthGate();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<fb.User?>(
      stream: fb.FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        final fb.User? user = snap.data;
        if (user == null) {
          return const LoginScreen();
        }
        return const RootShell();
      },
    );
  }
}

// (Опционально) Твой дамп Hive — оставил без изменений
Future<void> dumpHive() async {
  final regionBox = Hive.box<Region>('regions');
  final placeBox  = Hive.box<Place>('places');

  debugPrint('--- REGIONS (${regionBox.length}) ---');
  for (final key in regionBox.keys) {
    final r = regionBox.get(key)!;
    debugPrint('key=$key | region.id=${r.id} | name=${r.name}');
  }

  debugPrint('--- PLACES (${placeBox.length}) ---');
  for (final key in placeBox.keys) {
    final p = placeBox.get(key)!;
    debugPrint('key=$key | place.id=${p.id} | name=${p.name} | regionId=${p.regionId}');
  }
}
