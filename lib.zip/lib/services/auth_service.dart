// lib/services/auth_service.dart
import 'package:hive/hive.dart';
import '../models/user.dart'; // твоя Hive-модель User
import 'package:collection/collection.dart';

// Firebase
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;

class AuthService {
  // ===== Локальные боксы (оставляем для совместимости UI) =====
  final Box<User> _userBox = Hive.box<User>('users');

  // ===== Firebase =====
  final fb.FirebaseAuth _fa = fb.FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  fb.User? get firebaseUser => _fa.currentUser;

  DocumentReference<Map<String, dynamic>> _userDoc(String uid) =>
      _db.collection('users').doc(uid);

  Future<Box> _sessionBox() => Hive.openBox('session');

  Future<void> _writeSession({
    required String email,
    required bool isAdmin,
  }) async {
    final session = await _sessionBox();
    // Пароль в сессии не храним
    await session.put(
      'user',
      User(email: email, password: '', isAdmin: isAdmin),
    );
  }

  Future<User?> _sessionUser() async {
    final session = await _sessionBox();
    return session.get('user') as User?;
  }

  Future<bool> _pullRemoteProfileToSession() async {
    final fb.User? u = _fa.currentUser;
    if (u == null) return false;

    final snap = await _userDoc(u.uid).get();
    if (!snap.exists) return false;

    final data = snap.data()!;
    final email = (data['email'] as String?) ?? u.email ?? '';
    final role = (data['role'] as String?) ?? 'user';
    final isAdmin = role == 'admin';
    await _writeSession(email: email, isAdmin: isAdmin);
    return true;
  }

  /// Залогинить анонимно, если никого нет (можно вызывать в main()).
  Future<void> signInAnonymouslyIfNeeded() async {
    if (_fa.currentUser == null) {
      await _fa.signInAnonymously();
    }
  }

  // ================== ПУБЛИЧНЫЕ МЕТОДЫ ==================

  /// Регистрация через Firebase. Если текущий пользователь анонимный — линкуем.
  Future<bool> register(String email, String password,
      {bool isAdmin = false}) async {
    try {
      final fb.User? cur = _fa.currentUser;
      if (cur != null && cur.isAnonymous) {
        final cred = fb.EmailAuthProvider.credential(
            email: email, password: password);
        final res = await cur.linkWithCredential(cred); // uid сохраняется
        await _userDoc(res.user!.uid).set({
          'email': email,
          'displayName': res.user!.displayName ?? '',
          'photoUrl': res.user!.photoURL,
          'role': isAdmin ? 'admin' : 'user',
          'provider': 'password',
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      } else {
        final res = await _fa.createUserWithEmailAndPassword(
            email: email, password: password);
        await _userDoc(res.user!.uid).set({
          'email': email,
          'displayName': res.user!.displayName ?? '',
          'photoUrl': res.user!.photoURL,
          'role': isAdmin ? 'admin' : 'user',
          'provider': 'password',
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }

      await _writeSession(email: email, isAdmin: isAdmin);
      return true;
    } on fb.FirebaseAuthException {
      rethrow; // пробрасываем, чтобы UI поймал и показал конкретный код ошибки
    } catch (_) {
      rethrow;
    }
  }

  /// Вход через Firebase.
  Future<bool> login(String email, String password) async {
    try {
      final res = await _fa.signInWithEmailAndPassword(
          email: email, password: password);

      // Гарантируем наличие профиля в Firestore
      await _userDoc(res.user!.uid).set({
        'email': email,
        'displayName': res.user!.displayName ?? '',
        'photoUrl': res.user!.photoURL,
        'provider': 'password',
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      // Подтягиваем роль в локальную session
      final ok = await _pullRemoteProfileToSession();
      if (!ok) {
        await _writeSession(email: email, isAdmin: false);
      }
      return true;
    } on fb.FirebaseAuthException {
      rethrow;
    } catch (_) {
      rethrow;
    }
  }

  /// Возвращает пользователя из локальной session.
  Future<User?> getLoggedInUser() async {
    final cached = await _sessionUser();
    if (cached != null) return cached;

    if (_fa.currentUser != null) {
      final ok = await _pullRemoteProfileToSession();
      if (ok) return await _sessionUser();
    }
    return null;
  }

  /// Выход: Firebase signOut + очистка локальной session.
  Future<void> logout() async {
    await _fa.signOut();
    final session = await _sessionBox();
    await session.clear();
  }

  // ================== Методы настроек ==================

  /// Проверка пароля (reauthenticate).
  Future<bool> verifyPassword(String email, String currentPassword) async {
    try {
      final fb.User? u = _fa.currentUser;
      final cred = fb.EmailAuthProvider.credential(
          email: email, password: currentPassword);
      if (u != null && (u.email == email || u.isAnonymous)) {
        await u.reauthenticateWithCredential(cred);
        return true;
      }
      // Фолбэк
      await _fa.signInWithEmailAndPassword(
          email: email, password: currentPassword);
      await _fa.signOut();
      return true;
    } on fb.FirebaseAuthException {
      rethrow;
    } catch (_) {
      rethrow;
    }
  }

  /// Смена email.
  Future<void> updateEmail({
    required String currentEmail,
    required String currentPassword,
    required String newEmail,
  }) async {
    final ok = await verifyPassword(currentEmail, currentPassword);
    if (!ok) {
      throw Exception('Неверный текущий пароль');
    }

    final fb.User? u = _fa.currentUser;
    if (u == null) {
      throw Exception('Пользователь не найден');
    }

    await u.updateEmail(newEmail);

    await _userDoc(u.uid).set({
      'email': newEmail,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    final prev = await _sessionUser();
    await _writeSession(email: newEmail, isAdmin: prev?.isAdmin ?? false);
  }

  /// Смена пароля.
  Future<void> updatePassword({
    required String email,
    required String currentPassword,
    required String newPassword,
  }) async {
    final ok = await verifyPassword(email, currentPassword);
    if (!ok) {
      throw Exception('Неверный текущий пароль');
    }

    final fb.User? u = _fa.currentUser;
    if (u == null) {
      throw Exception('Пользователь не найден');
    }
    await u.updatePassword(newPassword);
  }

  // ================== Устаревшие локальные методы (Hive) ==================

  Future<bool> _registerLocal(String email, String password,
      {bool isAdmin = false}) async {
    final exists = _userBox.values.any((u) => u.email == email);
    if (exists) return false;

    final user = User(email: email, password: password, isAdmin: isAdmin);
    await _userBox.add(user);

    final session = await _sessionBox();
    await session.put(
        'user', User(email: user.email, password: '', isAdmin: user.isAdmin));
    return true;
  }

  Future<bool> _loginLocal(String email, String password) async {
    final user = _userBox.values
        .firstWhereOrNull((u) => u.email == email && u.password == password);
    if (user == null) return false;

    final session = await _sessionBox();
    await session.put(
        'user', User(email: user.email, password: '', isAdmin: user.isAdmin));
    return true;
  }
}

extension on fb.User {
  Future<void> updateEmail(String newEmail) async {}
}
