// lib/services/search_service.dart
// Сервис поиска + экран SearchView + страница SearchPage (с градиентом)

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/adapters.dart';

import '../models/place.dart';
import './likes_service.dart';
import '../widgets/kt_place_card.dart';

/// Градиент бренда (голубой → тёплый жёлтый)
const List<Color> _kGradientColors = [
  Color(0xff8ddeff),
  Color(0xfffff3b0),
];

// =========================
class SearchQuery {
  SearchQuery({
    required this.terms,
    required this.tags,
    required this.subcategories,
    this.regionId,
  });

  final List<String> terms;
  final Set<String> tags;
  final Set<String> subcategories;
  final String? regionId;

  factory SearchQuery.parse(String raw) {
    final parts = raw.trim().split(RegExp(r'\s+'));
    final List<String> terms = [];
    final Set<String> tags = {};
    final Set<String> subs = {};
    String? regionId;

    for (final token in parts) {
      if (token.isEmpty) continue;
      final t = token.trim();
      final tt = t.replaceAll(r'\"', '"');

      if (tt.startsWith('@')) {
        final v = _stripQuotes(tt.substring(1));
        if (v.isNotEmpty) subs.add(v.toLowerCase());
        continue;
      }

      if (tt.startsWith('#')) {
        final v = _stripQuotes(tt.substring(1));
        if (v.isNotEmpty) tags.add(v.toLowerCase());
        continue;
      }

      if (tt.startsWith('region:') && tt.length > 7) {
        regionId = tt.substring(7);
        continue;
      }

      final v = _stripQuotes(tt);
      if (v.isNotEmpty) terms.add(v.toLowerCase());
    }

    return SearchQuery(
      terms: terms,
      tags: tags,
      subcategories: subs,
      regionId: regionId,
    );
  }

  static String _stripQuotes(String s) {
    var trimmed = s.trim();
    final startsQuote = trimmed.startsWith('"') || trimmed.startsWith('“');
    final endsQuote = trimmed.endsWith('"') || trimmed.endsWith('”');
    if (startsQuote && !endsQuote) {
      trimmed = trimmed.substring(1);
      return trimmed;
    }
    if (trimmed.length >= 2 &&
        ((trimmed.startsWith('"') && trimmed.endsWith('"')) ||
            (trimmed.startsWith('“') && trimmed.endsWith('”')))) {
      return trimmed.substring(1, trimmed.length - 1);
    }
    return trimmed;
  }
}

// =========================
// СЕРВИС ПОИСКА (без UI)
// =========================
class SearchService {
  final Box<Place> _places = Hive.box<Place>('places');

  List<Place> searchSync(String raw, {int limit = 50}) {
    final q = SearchQuery.parse(raw);
    final all = _places.values.toList(growable: false);
    if (all.isEmpty) return const [];

    final scored = <_ScoredPlace>[];
    for (final p in all) {
      if (_matches(p, q)) {
        final s = _score(p, q);
        scored.add(_ScoredPlace(p, s));
      }
    }
    scored.sort((a, b) => b.score.compareTo(a.score));
    return scored.take(limit).map((e) => e.place).toList(growable: false);
  }

  Future<List<Place>> search(String raw, {int limit = 50}) async {
    return searchSync(raw, limit: limit);
  }

  String _s(dynamic v) {
    if (v == null) return '';
    if (v is String) return v.toLowerCase();
    if (v is Iterable) {
      return v.map((e) => e?.toString() ?? '').join(' ').toLowerCase();
    }
    return v.toString().toLowerCase();
  }

  bool _matches(Place p, SearchQuery q) {
    final name        = _s(p.name);
    final desc        = _s(p.description);
    final address     = _s(p.address);
    final category    = _s(p.category);
    final subcategory = _s(p.subcategories);
    final regionId    = (p.regionId ?? '');

    if (q.regionId != null && q.regionId!.isNotEmpty) {
      if (regionId != q.regionId) return false;
    }

    for (final s in q.subcategories) {
      if (s.isEmpty) continue;
      if (!(subcategory.contains(s) || name.contains(s) || desc.contains(s))) {
        return false;
      }
    }

    for (final t in q.tags) {
      if (t.isEmpty) continue;
      if (!(category.contains(t) || subcategory.contains(t) || name.contains(t) || desc.contains(t))) {
        return false;
      }
    }

    for (final term in q.terms) {
      if (term.isEmpty) continue;
      if (!(name.contains(term) || desc.contains(term) || address.contains(term) ||
          category.contains(term) || subcategory.contains(term))) {
        return false;
      }
    }

    return true;
  }

  int _score(Place p, SearchQuery q) {
    int s = 0;
    final name        = _s(p.name);
    final desc        = _s(p.description);
    final address     = _s(p.address);
    final category    = _s(p.category);
    final subcategory = _s(p.subcategories);

    for (final term in q.terms) {
      if (term.isEmpty) continue;
      if (name.startsWith(term)) s += 25;
      else if (name.contains(term)) s += 18;
      if (desc.contains(term)) s += 8;
      if (address.contains(term)) s += 6;
      if (category.contains(term)) s += 5;
      if (subcategory.contains(term)) s += 7;
    }

    for (final sub in q.subcategories) {
      if (subcategory == sub) s += 24;
      else if (subcategory.contains(sub)) s += 12;
    }
    for (final tag in q.tags) {
      if (category == tag) s += 20;
      else if (category.contains(tag)) s += 10;
    }

    if (q.regionId != null && (p.regionId ?? '') == q.regionId) {
      s += 30;
    }

    return s;
  }
}

class _ScoredPlace {
  _ScoredPlace(this.place, this.score);
  final Place place;
  final int score;
}

// =========================
// UI: Страница с градиентом
// =========================
class SearchPage extends StatelessWidget {
  const SearchPage({Key? key, this.initialQuery}) : super(key: key);

  final String? initialQuery;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent, // чтобы не перекрыть градиент
      appBar: AppBar(
        title: const Text('Поиск'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: _kGradientColors,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Container(
        constraints: const BoxConstraints.expand(),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: _kGradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          top: false, // уже перекрыто AppBar
          child: SearchView(initialQuery: initialQuery),
        ),
      ),
    );
  }
}

// =========================
// UI: Экран поиска (контент)
// =========================
class SearchView extends StatefulWidget {
  const SearchView({Key? key, this.initialQuery}) : super(key: key);
  final String? initialQuery;

  @override
  State<SearchView> createState() => _SearchViewState();
}

class _SearchViewState extends State<SearchView> {
  final _svc = SearchService();
  final _likes = LikesService();
  final _ctrl = TextEditingController();
  Timer? _debounce;

  List<Place> _results = const [];
  String _lastQuery = '';

  late final int _suggestSeed;

  @override
  void initState() {
    super.initState();
    _suggestSeed = DateTime.now().millisecondsSinceEpoch;
    _ctrl.addListener(_onChanged);

    final iq = widget.initialQuery?.trim();
    if (iq != null && iq.isNotEmpty) {
      _ctrl.text = iq;
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _ctrl.removeListener(_onChanged);
    _ctrl.dispose();
    super.dispose();
  }

  void _onChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), _runSearch);
  }

  Future<void> _runSearch() async {
    final q = _ctrl.text.trim();
    if (q == _lastQuery) return;
    _lastQuery = q;

    if (q.isEmpty) {
      if (mounted) setState(() => _results = const []);
      return;
    }

    final res = await _svc.search(q, limit: 100);
    if (mounted) setState(() => _results = res);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Поле поиска на градиенте
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: TextField(
            controller: _ctrl,
            decoration: InputDecoration(
              hintText: 'Поиск: текст, #тег, @подкатегория, region:ID',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white.withOpacity(0.92),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            ),
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _runSearch(),
          ),
        ),

        Expanded(
          child: ValueListenableBuilder(
            valueListenable: Hive.box<Place>('places').listenable(),
            builder: (context, _, __) {
              return ValueListenableBuilder<Box<int>>(
                valueListenable: _likes.listenable(),
                builder: (context, __, ___) {
                  if (_lastQuery.isNotEmpty) {
                    _results = _svc.searchSync(_lastQuery, limit: 100);
                  }

                  if (_lastQuery.isEmpty) {
                    final box = Hive.box<Place>('places');
                    final all = box.values.toList(growable: false);
                    final suggestions = _pickThree(all);
                    if (suggestions.isEmpty) {
                      return const Center(child: Text('Нет данных для показа'));
                    }
                    return ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: suggestions.length,
                      itemBuilder: (context, i) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: KtPlaceCard(place: suggestions[i]),
                      ),
                    );
                  }

                  if (_results.isEmpty) {
                    return const Center(child: Text('Ничего не найдено. Попробуйте другой запрос.'));
                  }

                  return ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _results.length,
                    itemBuilder: (context, i) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: KtPlaceCard(place: _results[i]),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }

  List<Place> _pickThree(List<Place> all) {
    if (all.isEmpty) return const [];
    if (all.length <= 3) return List<Place>.from(all);

    final r = Random(_suggestSeed);
    final selected = <Place>[];
    final used = <int>{};
    while (selected.length < 3 && used.length < all.length) {
      final idx = r.nextInt(all.length);
      if (used.add(idx)) selected.add(all[idx]);
    }
    return selected;
  }
}
