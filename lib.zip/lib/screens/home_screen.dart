import 'dart:async';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:html/parser.dart' as parser;
import 'package:url_launcher/url_launcher.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../widgets/root_shell_host.dart';
import '../utils/place_categories.dart';
import '../screens/direction_screen.dart';
import '../models/place.dart';
import '../services/place_service.dart';
import '../services/likes_service.dart';
import '../widgets/kt_place_card.dart';
// ▼ экран поиска
import '../services/search_service.dart';

enum Season { winter, spring, summer, autumn }
enum DayTime { morning, day, evening, night }

class HomeScreen extends StatefulWidget {
  /// Для тестов можно передать фиксированное время (тогда таймер не нужен).
  final DateTime? testDate;
  const HomeScreen({super.key, this.testDate});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _placeService = PlaceService();
  final _likes = LikesService();

  // 🎨 Цвета из вашего ТЗ
  static const Color blue = Color(0xFF2A5CAA);
  static const Color yellow = Color(0xFFFFD600);

  Timer? _tick;
  late DayTime _currentDayTime;

  @override
  void initState() {
    super.initState();
    _currentDayTime = _getDayTime(widget.testDate ?? DateTime.now());
    // Если не тестируем фиксированным временем — обновляем раз в минуту
    if (widget.testDate == null) {
      _tick = Timer.periodic(const Duration(minutes: 1), (_) {
        final dt = _getDayTime(DateTime.now());
        if (dt != _currentDayTime) {
          setState(() => _currentDayTime = dt);
        }
      });
    }
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  DayTime _getDayTime(DateTime now) {
    final h = now.hour;
    if (h >= 6 && h < 12) return DayTime.morning; // 06–12
    if (h < 18) return DayTime.day;                // 12–18
    if (h < 22) return DayTime.evening;            // 18–22
    return DayTime.night;                          // 22–06
  }

  // 🌄 Градиенты по времени суток
  // Утро — мягкий рассвет; День — белый/бежевый/светло-голубой;
  // Вечер/Ночь — глубокие синие и серые, под звёздное небо.
  BoxDecoration _decorationForTime(DayTime dt) {
    switch (dt) {
      case DayTime.morning:
        return const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFFFF8E1), // мягкий крем
              Color(0xFFFFECB3), // тёплый янтарь
              Color(0xFFB3E5FC), // светло-голубой
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        );
      case DayTime.day:
        return const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFFFFFFF), // белый
              Color(0xFFF5F5DC), // бежевый (beige)
              Color(0xFFD6EDFF), // светло-голубой
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        );
      case DayTime.evening:
        return const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF0D47A1), // глубокий синий
              Color(0xFF263238), // тёмно-серо-синий (blue-grey)
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        );
      case DayTime.night:
        return const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF00172D), // очень тёмный синий
              Color(0xFF2C3E50), // тёмный серо-синий
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        );
    }
  }

  // Чтобы категории были контекстные (пример из вашего кода)
  List<String> get dynamicSubcategories {
    final now = widget.testDate ?? DateTime.now();
    final dt = _getDayTime(now);
    final timeKey = _dayTimeKey(dt);

    final list = subcategoryToCategories.keys.where((sub) {
      final cats = subcategoryToCategories[sub]!;
      return cats.contains(timeKey);
    }).toList();
    list.shuffle();
    return list;
  }

  Stream<List<Place>> _popularPlacesStream({
    int limit = 4,
    Duration window = const Duration(days: 30),
  }) {
    final since = Timestamp.fromDate(DateTime.now().subtract(window));
    final placesBox = Hive.box<Place>('places'); // открыт при старте приложения

    return FirebaseFirestore.instance
        .collection('likes')
        .where('createdAt', isGreaterThan: since) // убери строку — будет "за всё время"
        .snapshots()
        .map((qs) {
      final counts = <String, int>{};
      for (final d in qs.docs) {
        final pid = (d.data()['placeId'] ?? '') as String;
        if (pid.isEmpty) continue;
        counts[pid] = (counts[pid] ?? 0) + 1;
      }
      final sorted = counts.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      final ids = sorted.take(limit).map((e) => e.key);

      final result = <Place>[];
      for (final id in ids) {
        final p = placesBox.get(id);
        if (p != null) result.add(p);
      }
      return result;
    });
  }

  String _dayTimeKey(DayTime dt) {
    switch (dt) {
      case DayTime.morning:
        return 'Утренняя экскурсия';
      case DayTime.day:
        return 'День';
      case DayTime.evening:
        return 'Вечерняя программа';
      case DayTime.night:
        return 'Ночная экскурсия';
    }
  }

  // ✨ Кнопка
  Widget _buildDirectionsButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12),
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xff8ddeff),
            foregroundColor: const Color(0xff000E6B),
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            elevation: 3,
          ),
          onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DirectionsScreen()),
            );
          },
          icon: const Icon(Icons.map_outlined),
          label: const Text(
            'Открыть направления',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ),
      ),
    );
  }

  // ← открытие поиска по подкатегории
  void _openSearchBySubcategory(BuildContext context, String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;

    final String query = trimmed.contains(' ') ? '@"$trimmed"' : '@$trimmed';

    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SearchView(initialQuery: query)),
    );
  }

  Widget _buildCategories() {
    final cats = dynamicSubcategories;
    return Container(
      height: 60,
      margin: const EdgeInsets.only(top: 8),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: cats.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final name = cats[index];
          return ActionChip(
            label: Text(name, style: const TextStyle(color: Color(0xff000E6B))),
            backgroundColor: yellow,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            onPressed: () => _openSearchBySubcategory(context, name),
          );
        },
      ),
    );
  }

  Widget _popularHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Популярные места',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: blue,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPopularPlaces() {
    return StreamBuilder<List<Place>>(
      stream: _popularPlacesStream(limit: 4, window: const Duration(days: 30)),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(child: CircularProgressIndicator(strokeWidth: 3)),
          );
        }
        final data = snap.data ?? const <Place>[];
        if (data.isEmpty) {
          return const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text('Ещё нет популярных мест — ставьте лайки на страницах мест.'),
          );
        }

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: data.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.80,
            ),
            itemBuilder: (context, i) => KtPlaceCard(place: data[i]),
          ),
        );
      },
    );
  }

  // 📰 Новости (3 карточки горизонтально)
  Widget _buildNews() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Text(
            "Новости",
            style: TextStyle(color: Color(0xff000E6B), fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
        SizedBox(
          height: 180,
          child: FutureBuilder<List<Map<String, String>>>(
            future: NewsService().fetchNews(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(child: Text("Нет новостей"));
              }

              final news = snapshot.data!;

              return ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: news.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (context, i) {
                  final n = news[i];
                  return SizedBox(
                    width: 280,
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 3,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              n["date"] ?? "",
                              style: const TextStyle(fontSize: 12, color: Color(0xff000E6B)),
                            ),
                            const SizedBox(height: 8),
                            Expanded(
                              child: Text(
                                n["title"] ?? "",
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: blue,
                                ),
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomRight,
                              child: IconButton(
                                icon: const Icon(Icons.arrow_forward_ios, size: 16, color: blue),
                                onPressed: () async {
                                  final urlStr = n["link"];
                                  if (urlStr == null || urlStr.isEmpty) return;
                                  final url = Uri.parse(urlStr);
                                  if (await canLaunchUrl(url)) {
                                    await launchUrl(url, mode: LaunchMode.externalApplication);
                                  }
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final now = widget.testDate ?? DateTime.now();
    // Если testDate задан — фиксируем время; иначе используем _currentDayTime (таймер сам обновит)
    final dayTime = widget.testDate != null ? _getDayTime(now) : _currentDayTime;

    // Плавная анимация смены фона при переходе между периодами суток
    return AnimatedContainer(
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeInOut,
      decoration: _decorationForTime(dayTime),
      child: Scaffold(
        backgroundColor: Colors.transparent, // ← не перекрываем градиент
        extendBody: true,
        body: SafeArea(
          bottom: true,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(bottom: RootShellHost.bottomGap),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // 🌅 Баннер: для вечер/ночь делаем темнее текст/фон для контраста
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
                  color: (dayTime == DayTime.evening || dayTime == DayTime.night)
                      ? const Color(0xFF0D47A1).withOpacity(0.85)
                      : const Color(0xff8ddeff),
                  child: Text(
                    "Открой Казахстан вместе с нами ",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: (dayTime == DayTime.evening || dayTime == DayTime.night)
                          ? Colors.white
                          : const Color(0xff000E6B),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),

                // 📰 Новости выше кнопки
                _buildNews(),

                _buildDirectionsButton(context),
                _buildCategories(),
                _popularHeader(context),
                _buildPopularPlaces(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// 🛠️ Сервис парсинга новостей
class NewsService {
  Future<List<Map<String, String>>> fetchNews() async {
    final res = await http.get(Uri.parse("https://travelpress.kz/news/main"));
    if (res.statusCode == 200) {
      final document = parser.parse(res.body);

      final items = document.querySelectorAll(
        "div.news-item, div.item_news, div[class*=news]",
      );

      return items.take(3).map((e) {
        final titleEl = e.querySelector("a.title-link, a[href][class*=title], .news-title a");
        final dateEl = e.querySelector(".news-date, .date, time");
        String link = "";
        if (titleEl != null) {
          final href = titleEl.attributes["href"];
          if (href != null) {
            link = href.startsWith("http") ? href : "https://travelpress.kz$href";
          }
        }
        return {
          "title": titleEl?.text.trim() ?? "Без заголовка",
          "date": dateEl?.text.trim() ?? "",
          "link": link,
        };
      }).toList();
    }
    return [];
  }
}
