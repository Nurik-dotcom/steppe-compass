import 'dart:async';
import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'login_screen.dart';
import 'admin_panel_screen.dart';
import 'favorites_screen.dart';
import 'debug_data_screen.dart';

// Firebase
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;

/// Цвета из ТЗ
const Color _kButtonBg = Color(0xff8ddeff);
const Color _kButtonText = Color(0xff000E6B);

/// Периоды суток для динамичного градиента
enum _DayTime { morning, day, evening, night }

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({Key? key}) : super(key: key);

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  final _auth = AuthService();

  // Контроллеры для email/password
  final _emailFormKey = GlobalKey<FormState>();
  final _passFormKey = GlobalKey<FormState>();
  final _currentEmailC = TextEditingController();
  final _currentPassForEmailC = TextEditingController();
  final _newEmailC = TextEditingController();
  final _currentPassC = TextEditingController();
  final _newPassC = TextEditingController();

  // Динамичный фон
  Timer? _tick;
  late _DayTime _currentDayTime;

  @override
  void initState() {
    super.initState();

    // Предзаполним текущий email из FirebaseAuth (если есть)
    final fbUser = fb.FirebaseAuth.instance.currentUser;
    if (fbUser?.email != null && _currentEmailC.text.isEmpty) {
      _currentEmailC.text = fbUser!.email!;
    }

    _currentDayTime = _getDayTime(DateTime.now());
    _tick = Timer.periodic(const Duration(minutes: 1), (_) {
      final dt = _getDayTime(DateTime.now());
      if (dt != _currentDayTime) {
        setState(() => _currentDayTime = dt);
      }
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    _currentEmailC.dispose();
    _currentPassForEmailC.dispose();
    _newEmailC.dispose();
    _currentPassC.dispose();
    _newPassC.dispose();
    super.dispose();
  }

  _DayTime _getDayTime(DateTime now) {
    final h = now.hour;
    if (h >= 6 && h < 12) return _DayTime.morning; // 06–12
    if (h < 18) return _DayTime.day;                // 12–18
    if (h < 22) return _DayTime.evening;            // 18–22
    return _DayTime.night;                          // 22–06
  }

  LinearGradient _gradientFor(_DayTime dt) {
    switch (dt) {
      case _DayTime.morning:
        return const LinearGradient(
          colors: [
            Color(0xFFFFF8E1), // мягкий крем
            Color(0xFFFFECB3), // тёплый янтарь
            Color(0xFFB3E5FC), // светло-голубой
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        );
      case _DayTime.day:
        return const LinearGradient(
          colors: [
            Color(0xFFFFFFFF), // белый
            Color(0xFFF5F5DC), // бежевый
            Color(0xFFD6EDFF), // светло-голубой
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        );
      case _DayTime.evening:
        return const LinearGradient(
          colors: [
            Color(0xFF0D47A1), // глубокий синий
            Color(0xFF263238), // тёмно-серо-синий
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        );
      case _DayTime.night:
        return const LinearGradient(
          colors: [
            Color(0xFF00172D), // очень тёмный синий
            Color(0xFF2C3E50), // тёмный серо-синий
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        );
    }
  }

  BoxDecoration _decorationFor(_DayTime dt) => BoxDecoration(gradient: _gradientFor(dt));

  /// ======== Actions ========= ///

  Future<void> _logout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Выйти из аккаунта?'),
        content: const Text('Вы будете перенаправлены на экран входа.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Выйти')),
        ],
      ),
    );

    if (confirm != true) return;

    await _auth.logout();

    if (!mounted) return;
    Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
          (route) => false,
    );
  }

  void _showChangeEmailDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text("Изменить Email"),
        content: Form(
          key: _emailFormKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _currentEmailC,
                  decoration: const InputDecoration(labelText: "Текущий Email"),
                  validator: (v) => v == null || v.trim().isEmpty ? "Введите текущий email" : null,
                ),
                TextFormField(
                  controller: _currentPassForEmailC,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: "Пароль"),
                  validator: (v) => v == null || v.isEmpty ? "Введите пароль" : null,
                ),
                TextFormField(
                  controller: _newEmailC,
                  decoration: const InputDecoration(labelText: "Новый Email"),
                  validator: (v) => v == null || v.trim().isEmpty ? "Введите новый email" : null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Отмена")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _kButtonBg, foregroundColor: _kButtonText),
            onPressed: () async {
              if (!_emailFormKey.currentState!.validate()) return;
              FocusScope.of(context).unfocus();
              try {
                await _auth.updateEmail(
                  currentEmail: _currentEmailC.text.trim(),
                  currentPassword: _currentPassForEmailC.text,
                  newEmail: _newEmailC.text.trim(),
                );
                if (!mounted) return;
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Email обновлён')));
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
              }
            },
            child: const Text("Сохранить"),
          ),
        ],
      ),
    );
  }

  void _showChangePasswordDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text("Изменить пароль"),
        content: Form(
          key: _passFormKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // email префиллим и не редактируем
                TextFormField(
                  controller: _currentEmailC,
                  readOnly: true,
                  decoration: const InputDecoration(labelText: "Email"),
                ),
                TextFormField(
                  controller: _currentPassC,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: "Текущий пароль"),
                  validator: (v) => v == null || v.isEmpty ? "Введите текущий пароль" : null,
                ),
                TextFormField(
                  controller: _newPassC,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: "Новый пароль"),
                  validator: (v) => v == null || v.length < 6 ? "Минимум 6 символов" : null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Отмена")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _kButtonBg, foregroundColor: _kButtonText),
            onPressed: () async {
              if (!_passFormKey.currentState!.validate()) return;
              FocusScope.of(context).unfocus();
              try {
                await _auth.updatePassword(
                  currentPassword: _currentPassC.text,
                  newPassword: _newPassC.text,
                  email: _currentEmailC.text.trim(),
                );
                if (!mounted) return;
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Пароль обновлён')));
              } catch (e) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
              }
            },
            child: const Text("Сохранить"),
          ),
        ],
      ),
    );
  }

  /// ======== UI helpers ========= ///

  Widget _buildActionTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Icon(icon, color: _kButtonText),
        title: Text(title, style: const TextStyle(fontSize: 16)),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final fbUser = fb.FirebaseAuth.instance.currentUser;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeInOut,
      decoration: _decorationFor(_currentDayTime),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text("Профиль"),
          // Градиент в шапке — тот же, что и на фоне, для цельности
          flexibleSpace: Container(decoration: BoxDecoration(gradient: _gradientFor(_currentDayTime))),
        ),
        body: fbUser == null
            ? const Center(child: Text("Вы не авторизованы"))
            : StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection('users').doc(fbUser.uid).snapshots(),
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            final data = snap.data?.data() ?? <String, dynamic>{};
            final email = (data['email'] as String?) ?? fbUser.email ?? '';
            final displayName = (data['displayName'] as String?) ?? '';
            final role = (data['role'] as String?) ?? 'user';
            final isAdmin = role == 'admin';

            // аккуратно поддержим контроллер email в формах изменений
            if (_currentEmailC.text.isEmpty && email.isNotEmpty) {
              _currentEmailC.text = email;
            }

            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const SizedBox(height: 12),
                if (displayName.isNotEmpty)
                  Center(
                    child: Text(
                      displayName,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.black87),
                    ),
                  ),
                Center(
                  child: Text(
                    email.isNotEmpty ? email : '(email не указан)',
                    style: const TextStyle(color: Colors.black54),
                  ),
                ),
                Center(
                  child: Text(
                    'Роль: $role',
                    style: const TextStyle(color: Colors.black45, fontSize: 12),
                  ),
                ),
                const SizedBox(height: 24),

                _buildActionTile(icon: Icons.email, title: "Изменить Email", onTap: _showChangeEmailDialog),
                _buildActionTile(icon: Icons.lock, title: "Изменить Пароль", onTap: _showChangePasswordDialog),

                _buildActionTile(
                  icon: Icons.favorite,
                  title: "Избранное",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const FavoritesScreen()));
                  },
                ),

                if (isAdmin)
                  _buildActionTile(
                    icon: Icons.admin_panel_settings,
                    title: "Админ-панель",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPanelScreen()));
                    },
                  ),

                if (isAdmin)
                  _buildActionTile(
                    icon: Icons.bug_report,
                    title: "Отладка",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const DebugDataScreen()));
                    },
                  ),

                _buildActionTile(icon: Icons.exit_to_app, title: "Выйти", onTap: _logout),
              ],
            );
          },
        ),
      ),
    );
  }
}
