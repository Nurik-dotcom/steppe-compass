import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

import '../models/place.dart';
import '../services/favorites_service.dart';
import '../services/auth_service.dart';
import 'place_detail_screen.dart';

/// Градиенты по ТЗ (голубой → тёплый жёлтый)
const List<Color> _kGradientColors = [
  Color(0xff8ddeff),
  Color(0xfffff3b0),
];

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  String _userId = 'guest';
  late Box<Place> _places;

  @override
  void initState() {
    super.initState();
    _places = Hive.box<Place>('places');
    _loadUser();
  }

  Future<void> _loadUser() async {
    final u = await AuthService().getLoggedInUser();
    setState(() => _userId = u?.email ?? 'guest');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Избранное'),
        // Градиент в AppBar
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: _kGradientColors,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        backgroundColor: Colors.transparent,
      ),
      // Градиент фона всего экрана
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: _kGradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: ValueListenableBuilder(
          valueListenable: FavoritesService.listenable(_userId),
          builder: (_, __, ___) {
            final ids = FavoritesService.all(_userId);
            final items = ids.map((id) => _places.get(id)).whereType<Place>().toList();

            if (items.isEmpty) {
              return const Center(
                child: Text(
                  'Список избранного пуст.',
                  style: TextStyle(fontSize: 16),
                ),
              );
            }

            return ListView.separated(
              itemCount: items.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final p = items[i];
                final img = (p.imageUrl.isNotEmpty) ? p.imageUrl.first : null;

                return ListTile(
                  tileColor: Colors.white.withOpacity(0.85), // чуть читаемости на градиенте
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: img == null
                        ? const Icon(Icons.photo, size: 40)
                        : (img.startsWith('http')
                        ? Image.network(img, width: 56, height: 56, fit: BoxFit.cover)
                        : Image.asset(img, width: 56, height: 56, fit: BoxFit.cover)),
                  ),
                  title: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: (p.description == null || p.description!.isEmpty)
                      ? null
                      : Text(
                    p.description!,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.favorite, color: Colors.redAccent),
                    onPressed: () => FavoritesService.toggle(_userId, p.id),
                    tooltip: 'Убрать из избранного',
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => PlaceDetailScreen(place: p)),
                    );
                  },
                );
              },
            );
          },
        ),
      ),
    );
  }
}
