import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../widgets/root_shell_host.dart';
import '../models/region.dart';
import '../models/place.dart';
import 'place_detail_screen.dart';
import '../widgets/kt_place_card.dart';

enum _Tab { attractions, restaurants, hotels }

const _tabTitles = <_Tab, String>{
  _Tab.attractions: 'Достопримечательности',
  _Tab.restaurants: 'Рестораны',
  _Tab.hotels: 'Отели',
};

const Set<String> _restSynonyms = {
  'Ресторан', 'Рестораны', 'Кафе',
  'restaurant', 'restaurants', 'cafe', 'coffee', 'coffee shop',
};

const Set<String> _hotelSynonyms = {
  'отель', 'отели', 'гостиница', 'гостиницы',
  'hotel', 'hotels', 'guesthouse', 'hostel', 'guest house',
};

// Светло-бежевый фон для всей страницы
const _kBeige = Color(0xFFF5F5DC);

String _norm(String? s) => (s ?? '').trim().toLowerCase();

extension _PlaceCategoryTags on Place {
  Set<String> _allCategoryTagsLower() {
    final out = <String>{};

    void addToken(String? raw) {
      final s = _norm(raw);
      if (s.isEmpty) return;
      final parts = s
          .split(RegExp(r'[,/|;]'))
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty);
      if (parts.isEmpty) {
        out.add(s);
      } else {
        out.addAll(parts);
      }
    }

    try {
      addToken((this as dynamic).category as String?);
    } catch (_) {}
    try {
      addToken((this as dynamic).subcategory as String?);
    } catch (_) {}
    try {
      final sc = (this as dynamic).subcategories;
      if (sc is List) {
        for (final v in sc) {
          if (v is String) addToken(v);
        }
      }
    } catch (_) {}

    return out;
  }

  bool _isRestaurantOrCafe() =>
      _allCategoryTagsLower().any(_restSynonyms.contains);
  bool _isHotel() => _allCategoryTagsLower().any(_hotelSynonyms.contains);
}

class _BouncyOnlyHere extends MaterialScrollBehavior {
  const _BouncyOnlyHere();

  @override
  Set<PointerDeviceKind> get dragDevices => {
    PointerDeviceKind.touch,
    PointerDeviceKind.mouse,
    PointerDeviceKind.trackpad,
    PointerDeviceKind.stylus,
    PointerDeviceKind.invertedStylus,
    PointerDeviceKind.unknown,
  };

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    return const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics());
  }
}

class RegionDetailScreen extends StatelessWidget {
  final Region region;
  const RegionDetailScreen({Key? key, required this.region}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final placesBox = Hive.box<Place>('places');

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(title: Text(region.name)),
        backgroundColor: _kBeige, // ← бежевый фон под всем экраном
        body: Container(
          color: _kBeige, // ← гарантируем бежевый под всем содержимым
          child: SafeArea(
            bottom: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _RegionHeader(region: region),
                const SizedBox(height: 12),

                // Вкладки
                Transform.translate(
                  offset: const Offset(0, -6),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 12),
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(
                      // Плашка под табы оставлена светлой и слегка прозрачной,
                      // чтобы хорошо читалась на бежевом фоне
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 10,
                          spreadRadius: 0,
                          offset: Offset(0, 4),
                          color: Color(0x14000000),
                        ),
                      ],
                    ),
                    child: const TabBar(
                      isScrollable: true,
                      indicatorSize: TabBarIndicatorSize.tab,
                      labelStyle: TextStyle(fontWeight: FontWeight.w600),
                      tabs: [
                        Tab(text: 'Достопримечательности'),
                        Tab(text: 'Рестораны'),
                        Tab(text: 'Отели'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 6),

                // Контент вкладок
                Expanded(
                  child: Transform.translate(
                    offset: const Offset(0, -6),
                    child: ScrollConfiguration(
                      behavior: const _BouncyOnlyHere(),
                      child: TabBarView(
                        children: [
                          _PlacesListForRegion(
                            regionId: region.id,
                            placesBox: placesBox,
                            tab: _Tab.attractions,
                          ),
                          _PlacesListForRegion(
                            regionId: region.id,
                            placesBox: placesBox,
                            tab: _Tab.restaurants,
                          ),
                          _PlacesListForRegion(
                            regionId: region.id,
                            placesBox: placesBox,
                            tab: _Tab.hotels,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RegionHeader extends StatelessWidget {
  final Region region;
  const _RegionHeader({Key? key, required this.region}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final imageUrl = region.imageUrl;
    final screenHeight = MediaQuery.of(context).size.height;

    // ограничиваем высоту изображения до 250
    final imageHeight = screenHeight * 0.25;
    final cappedHeight = imageHeight.clamp(0.0, 250.0);

    Widget image;
    if (imageUrl.isEmpty) {
      image = _placeholder(context, cappedHeight);
    } else if (imageUrl.startsWith('http')) {
      image = Image.network(
        imageUrl,
        height: cappedHeight,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _placeholder(context, cappedHeight),
      );
    } else {
      image = Image.asset(
        imageUrl,
        height: cappedHeight,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _placeholder(context, cappedHeight),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: const BorderRadius.vertical(bottom: Radius.circular(12)),
          child: image,
        ),
        if (region.description.trim().isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: Text(
              region.description,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
      ],
    );
  }

  Widget _placeholder(BuildContext context, double h) => Container(
    height: h,
    width: double.infinity,
    color: Theme.of(context).colorScheme.surfaceVariant,
    child: Center(
      child: Icon(
        Icons.landscape_outlined,
        size: 48,
        color: Theme.of(context).colorScheme.outline,
      ),
    ),
  );
}

class _PlacesListForRegion extends StatelessWidget {
  final String regionId;
  final Box<Place> placesBox;
  final _Tab tab;

  const _PlacesListForRegion({
    Key? key,
    required this.regionId,
    required this.placesBox,
    required this.tab,
  }) : super(key: key);

  bool _filter(Place p) {
    if (p.regionId != regionId) return false;

    final isRest = p._isRestaurantOrCafe();
    final isHotel = p._isHotel();

    switch (tab) {
      case _Tab.attractions:
        return !isRest && !isHotel;
      case _Tab.restaurants:
        return isRest;
      case _Tab.hotels:
        return isHotel;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: placesBox.listenable(),
      builder: (context, Box<Place> box, _) {
        final items = box.values.where(_filter).toList();

        if (items.isEmpty) {
          final msg = switch (tab) {
            _Tab.attractions => 'В этом регионе пока нет достопримечательностей.',
            _Tab.restaurants => 'В этом регионе пока нет ресторанов/кафе.',
            _Tab.hotels => 'В этом регионе пока нет отелей/гостиниц.',
          };
          return _EmptyState(title: 'Нет данных', subtitle: msg);
        }

        return ListView.separated(
          padding: EdgeInsets.fromLTRB(12, 8, 12, RootShellHost.bottomGap),
          physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (context, i) {
            final place = items[i];
            return InkWell(
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => PlaceDetailScreen(place: place)),
              ),
              child: KtPlaceCard(place: place),
            );
          },
        );
      },
    );
  }
}

class _EmptyState extends StatelessWidget {
  final String title;
  final String subtitle;
  const _EmptyState({Key? key, required this.title, required this.subtitle})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.place_outlined, size: 48, color: t.disabledColor),
            const SizedBox(height: 12),
            Text(title, style: t.textTheme.titleMedium),
            const SizedBox(height: 8),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: t.textTheme.bodyMedium?.copyWith(color: t.hintColor),
            ),
          ],
        ),
      ),
    );
  }
}
