// lib/screens/place_detail_screen.dart
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kReleaseMode;
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../widgets/root_shell_host.dart';
import '../widgets/rutube_embed.dart';
import '../widgets/rutube_preview_player.dart';

import '../models/place.dart';
import '../services/auth_service.dart';
import '../services/favorites_service.dart';
import '../services/likes_service.dart';

const _kBeige = Color(0xFFF5F5DC);

class PlaceDetailScreen extends StatefulWidget {
  final Place place;
  const PlaceDetailScreen({Key? key, required this.place}) : super(key: key);

  @override
  State<PlaceDetailScreen> createState() => _PlaceDetailScreenState();
}

String? _rutubeIdFromUrl(String? url) {
  if (url == null || url.isEmpty) return null;
  final patterns = [
    RegExp(r'rutube\.ru/(?:video|shorts)/([A-Za-z0-9_-]+)/?'),
    RegExp(r'rutube\.ru/play/embed/([A-Za-z0-9_-]+)'),
    RegExp(r'rutube\.ru/track/embed/([A-Za-z0-9_-]+)'),
    RegExp(r'rutube\.ru/video/private/([A-Za-z0-9_-]+)'),
    RegExp(r'[?&#](?:p|id)=([A-Za-z0-9_-]+)'),
  ];
  for (final p in patterns) {
    final m = p.firstMatch(url);
    if (m != null) return m.group(1);
  }
  return null;
}

class _PlaceDetailScreenState extends State<PlaceDetailScreen> {
  // --- controllers/state
  final _pageController = PageController();
  GoogleMapController? _mapController;
  final _likesRemote = LikesServiceRemote();

  // --- toggles for sections
  bool _showVideo = false;

  String? _rutubeId;
  bool _showMap = false;

  // --- images loading
  bool _imagesReady = false;
  Timer? _imagesTimeoutTimer;

  // --- location/distance
  bool _hasLocationPermission = false;
  Position? _currentPosition;
  double? _distanceMeters;

  // --- misc
  String _userId = 'guest';
  bool _mapReady = false;

  @override
  void initState() {
    super.initState();

    _rutubeId = _rutubeIdFromUrl(_videoUrl);
    _initUser();
    _armImagesFallback();
    _maybePrefetchFirstImages();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _mapController?.dispose();
    _imagesTimeoutTimer?.cancel();
    super.dispose();
  }

  Future<void> _initUser() async {
    try {
      final user = await AuthService().getLoggedInUser();
      if (!mounted) return;
      setState(() => _userId = user?.email ?? 'guest');
    } catch (_) {}
  }

  void _armImagesFallback() {
    // если изображения не сообщили о готовности — через 2.5с снимаем плейсхолдер
    _imagesTimeoutTimer = Timer(const Duration(milliseconds: 2500), () {
      if (!mounted || _imagesReady) return;
      setState(() => _imagesReady = true);
    });
  }

  void _maybePrefetchFirstImages() {
    final images = _images();
    if (images.isEmpty) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      for (final url in images.take(2)) {
        if (url.startsWith('http')) {
          precacheImage(NetworkImage(url), context);
        }
      }
    });
  }

  // ---------- permissions & location ----------
  Future<void> _ensureLocationPermission() async {
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (!mounted) return;
    setState(() {
      _hasLocationPermission =
      (perm == LocationPermission.always || perm == LocationPermission.whileInUse);
    });
  }

  Future<void> _initLocationAndDistance() async {
    await _ensureLocationPermission();
    if (!_hasLocationPermission) return;

    try {
      final pos = await Geolocator.getCurrentPosition();
      if (!mounted) return;
      setState(() {
        _currentPosition = pos;
        if (_targetLatLng != null) {
          _distanceMeters = Geolocator.distanceBetween(
            pos.latitude,
            pos.longitude,
            _targetLatLng!.latitude,
            _targetLatLng!.longitude,
          );
        }
      });
    } catch (e) {
      debugPrint('initLocation error: $e');
    }
  }

  // ---------- model helpers ----------
  List<String> _images() {
    try {
      final imgs = (widget.place as dynamic).imageUrl;
      if (imgs is List) return imgs.cast<String>();
      if (imgs is String && imgs.isNotEmpty) return [imgs];
      return const <String>[];
    } catch (_) {
      return const <String>[];
    }
  }

  String? get _videoUrl {
    try {
      final v = (widget.place as dynamic).videoUrl as String?;
      if (v == null || v.trim().isEmpty) return null;
      return v.trim();
    } catch (_) {
      return null;
    }
  }

  LatLng? get _targetLatLng {
    try {
      final lat = (widget.place as dynamic).latitude as double?;
      final lng = (widget.place as dynamic).longitude as double?;
      if (lat == null || lng == null) return null;
      return LatLng(lat, lng);
    } catch (_) {
      return null;
    }
  }

  String? get _address {
    try {
      final v = (widget.place as dynamic).address as String?;
      return (v == null || v.trim().isEmpty) ? null : v.trim();
    } catch (_) {
      return null;
    }
  }

  String? get _workingHours {
    try {
      final v = (widget.place as dynamic).workingHours as String?;
      return (v == null || v.trim().isEmpty) ? null : v.trim();
    } catch (_) {
      return null;
    }
  }

  String? get _ticketPrice {
    try {
      final v = (widget.place as dynamic).ticketPrice as String?;
      return (v == null || v.trim().isEmpty) ? null : v.trim();
    } catch (_) {
      return null;
    }
  }

  void _onImagesAllLoaded() {
    if (_imagesReady) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _imagesReady) return;
      setState(() => _imagesReady = true);
      _imagesTimeoutTimer?.cancel();
    });
  }

  String _formatDistance(double m) {
    if (m >= 1000) return '${(m / 1000).toStringAsFixed(1)} км';
    return '${m.toStringAsFixed(0)} м';
  }

  // ---------------- UI ----------------
  @override
  Widget build(BuildContext context) {
    final images = _images();

    return Scaffold(
      backgroundColor: _kBeige, // ← бежевый фон под всей страницей
      appBar: AppBar(
        backgroundColor: Colors.transparent, // чтобы видеть бежевый под шапкой
        elevation: 0,
        title: Text(widget.place.name),
        actions: [
          // избранное
          ValueListenableBuilder(
            valueListenable: FavoritesService.listenable(_userId),
            builder: (_, __, ___) {
              final fav = FavoritesService.isFavorite(_userId, widget.place.id);
              return IconButton(
                tooltip: fav ? 'Убрать из избранного' : 'В избранное',
                icon: Icon(fav ? Icons.favorite : Icons.favorite_border),
                onPressed: () => FavoritesService.toggle(_userId, widget.place.id),
              );
            },
          ),
        ],
      ),

      body: Container(
        color: _kBeige, // ← гарантия бежевого под контентом/скроллом
        child: Stack(
          children: [
            SafeArea(
              bottom: true,
              child: SingleChildScrollView(
                padding: EdgeInsets.only(bottom: RootShellHost.bottomGap),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // --- Photos ---
                    if (images.isNotEmpty)
                      _PhotosCarousel(
                        images: images,
                        controller: _pageController,
                        onAllImagesLoaded: _onImagesAllLoaded,
                      )
                    else
                      const _ImagePlaceholder(height: 220),

                    const SizedBox(height: 16),

                    // --- Title ---
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        widget.place.name,
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),

                    const SizedBox(height: 8),

                    // --- Info chips ---
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: _InfoChips(
                        address: _address,
                        workingHours: _workingHours,
                        ticketPrice: _ticketPrice,
                        distanceText:
                        _distanceMeters == null ? null : _formatDistance(_distanceMeters!),
                      ),
                    ),

                    const SizedBox(height: 8),

                    // --- Likes + distance button ---
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Row(
                        children: [
                          // Кнопка лайка (реал-тайм)
                          StreamBuilder<bool>(
                            stream: _likesRemote.isLikedStream(widget.place.id),
                            builder: (context, snapLiked) {
                              final liked = snapLiked.data ?? false;
                              return IconButton(
                                tooltip: liked ? 'Убрать лайк' : 'Лайк',
                                icon: Icon(liked ? Icons.thumb_up : Icons.thumb_up_outlined),
                                onPressed: () => _likesRemote.toggleLike(widget.place.id),
                              );
                            },
                          ),
                          const SizedBox(width: 6),
                          // Счётчик лайков (реал-тайм)
                          StreamBuilder<int>(
                            stream: _likesRemote.likeCountStream(widget.place.id),
                            builder: (context, snapCount) {
                              final count = snapCount.data ?? 0;
                              return Text('$count');
                            },
                          ),
                        ],
                      ),
                    ),

                    // --- Description ---
                    if (widget.place.description.trim().isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Text(widget.place.description),
                      ),
                    ],

                    const SizedBox(height: 16),

                    // --- Видеообзор Rutube (lazy)
                    if (_videoUrl != null && _rutubeId != null) ...[
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        child: Text(
                          'Видеообзор',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 200),
                          switchInCurve: Curves.easeOut,
                          switchOutCurve: Curves.easeIn,
                          child: _showVideo
                              ? Stack(
                            key: const ValueKey('video_open'),
                            children: [
                              _RutubeLazyPlayer(url: _videoUrl!),
                              Positioned(
                                top: 8,
                                right: 8,
                                child: Material(
                                  color: Colors.black45,
                                  shape: const CircleBorder(),
                                  child: IconButton(
                                    tooltip: 'Скрыть видео',
                                    icon: const Icon(Icons.close, color: Colors.white),
                                    onPressed: () => setState(() => _showVideo = false),
                                  ),
                                ),
                              ),
                            ],
                          )
                              : GestureDetector(
                            key: const ValueKey('video_preview'),
                            behavior: HitTestBehavior.opaque,
                            onTap: () => setState(() => _showVideo = true),
                            child: RutubePreviewPlayer(videoId: _rutubeId!),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],

                    // --- Map section (toggle) ---
                    if (_targetLatLng != null) ...[
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        child: Text('На карте',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                      ),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: SizedBox(
                          height: 220,
                          child: AnimatedSwitcher(
                            duration: const Duration(milliseconds: 200),
                            child: !_showMap
                                ? _StubCard(
                              key: const ValueKey('map_stub'),
                              icon: Icons.map_outlined,
                              text: 'Показать на карте',
                              trailing: TextButton.icon(
                                onPressed: () async {
                                  await _ensureLocationPermission();
                                  if (mounted) setState(() => _showMap = true);
                                },
                                icon: const Icon(Icons.map),
                                label: const Text('Открыть'),
                              ),
                            )
                                : Stack(
                              key: const ValueKey('map_open'),
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: GoogleMap(
                                    liteModeEnabled: !kReleaseMode, // легче в debug
                                    myLocationEnabled:
                                    _hasLocationPermission, // только с разрешением
                                    myLocationButtonEnabled: _hasLocationPermission,
                                    mapType: MapType.normal,
                                    initialCameraPosition: CameraPosition(
                                      target: _targetLatLng!,
                                      zoom: 12.5,
                                    ),
                                    onMapCreated: (c) {
                                      _mapController = c;
                                      if (!_mapReady && mounted) {
                                        setState(() => _mapReady = true);
                                      }
                                    },
                                    markers: {
                                      Marker(
                                        markerId: const MarkerId('place'),
                                        position: _targetLatLng!,
                                        infoWindow:
                                        InfoWindow(title: widget.place.name),
                                      ),
                                    },
                                  ),
                                ),
                                Positioned(
                                  top: 8,
                                  right: 8,
                                  child: Material(
                                    color: Colors.black45,
                                    shape: const CircleBorder(),
                                    child: IconButton(
                                      tooltip: 'Скрыть карту',
                                      icon: const Icon(Icons.close, color: Colors.white),
                                      onPressed: () => setState(() => _showMap = false),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================== widgets ==================

class _StubCard extends StatelessWidget {
  final IconData icon;
  final String text;
  final Widget? trailing;

  const _StubCard({
    Key? key,
    required this.icon,
    required this.text,
    this.trailing,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant,
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(icon, size: 36, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

class _PhotosCarousel extends StatefulWidget {
  const _PhotosCarousel({
    Key? key,
    required this.images,
    required this.controller,
    required this.onAllImagesLoaded,
  }) : super(key: key);

  final List<String> images;
  final PageController controller;
  final VoidCallback onAllImagesLoaded;

  @override
  State<_PhotosCarousel> createState() => _PhotosCarouselState();
}

class _PhotosCarouselState extends State<_PhotosCarousel> {
  int _index = 0;
  bool _allLoaded = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        AspectRatio(
          aspectRatio: 16 / 9,
          child: PageView.builder(
            controller: widget.controller,
            onPageChanged: (i) => setState(() => _index = i),
            itemCount: widget.images.length,
            itemBuilder: (_, i) {
              final url = widget.images[i];
              final img = url.startsWith('http')
                  ? Image.network(
                url,
                fit: BoxFit.cover,
                frameBuilder: (ctx, child, frame, wasSync) {
                  if (frame != null && !_allLoaded) {
                    _allLoaded = true;
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      if (mounted) widget.onAllImagesLoaded();
                    });
                  }
                  return AnimatedOpacity(
                    opacity: frame == null ? 0 : 1,
                    duration: const Duration(milliseconds: 250),
                    child: child,
                  );
                },
                errorBuilder: (_, __, ___) => const _ImagePlaceholder(),
              )
                  : Image.asset(
                url,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const _ImagePlaceholder(),
              );
              return ClipRRect(
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(12),
                  bottomRight: Radius.circular(12),
                ),
                child: img,
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        _Dots(count: widget.images.length, index: _index),
      ],
    );
  }
}

class _Dots extends StatelessWidget {
  final int count;
  final int index;
  const _Dots({required this.count, required this.index});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        count,
            (i) => AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.symmetric(horizontal: 3),
          height: 6,
          width: i == index ? 16 : 6,
          decoration: BoxDecoration(
            color: i == index
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).colorScheme.outlineVariant,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
      ),
    );
  }
}

class _ImagePlaceholder extends StatelessWidget {
  final double? height;
  const _ImagePlaceholder({this.height});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      color: Theme.of(context).colorScheme.surfaceVariant,
      child: Center(
        child: Icon(Icons.landscape_outlined,
            size: 48, color: Theme.of(context).colorScheme.outline),
      ),
    );
  }
}

class _InfoChips extends StatelessWidget {
  final String? address;
  final String? workingHours;
  final String? ticketPrice;
  final String? distanceText;

  const _InfoChips({
    Key? key,
    this.address,
    this.workingHours,
    this.ticketPrice,
    this.distanceText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final chips = <Widget>[];
    if (address != null) {
      chips.add(_chip(Icons.location_on_outlined, address!));
    }
    if (workingHours != null) {
      chips.add(_chip(Icons.access_time, workingHours!));
    }
    if (ticketPrice != null) {
      chips.add(_chip(Icons.confirmation_number_outlined, ticketPrice!));
    }
    if (distanceText != null) {
      chips.add(_chip(Icons.route_outlined, distanceText!));
    }

    if (chips.isEmpty) return const SizedBox.shrink();

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: chips,
    );
  }

  Widget _chip(IconData icon, String text) {
    return Chip(
      avatar: Icon(icon, size: 18),
      label: Text(text),
      visualDensity: VisualDensity.compact,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
    );
  }
}

// ============== Rutube player via WebView ==============
class _RutubePlayer extends StatefulWidget {
  final String url;
  final VoidCallback? onReady;
  const _RutubePlayer({required this.url, this.onReady});

  @override
  State<_RutubePlayer> createState() => _RutubePlayerState();
}

class _RutubePlayerState extends State<_RutubePlayer> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    final uri = Uri.parse(_asEmbed(widget.url));
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) => widget.onReady?.call(),
          onWebResourceError: (_) => widget.onReady?.call(),
        ),
      )
      ..loadRequest(uri, headers: const {'Referer': 'https://rutube.ru'});
  }

  // преобразуем обычную ссылку rutube в /play/embed/...
  String _asEmbed(String input) {
    if (input.contains('/play/embed/')) return input;
    final id = RegExp(r'([a-f0-9]{32})', caseSensitive: false).firstMatch(input)?.group(1);
    if (id != null) return 'https://rutube.ru/play/embed/$id';
    return input; // fallback
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 16 / 9,
      child: WebViewWidget(controller: _controller),
    );
  }
}

/// ============== Rutube player with paused preview overlay (loaded but paused) ==============
class _RutubePlayerOverlay extends StatefulWidget {
  final String url;
  const _RutubePlayerOverlay({required this.url});

  @override
  State<_RutubePlayerOverlay> createState() => _RutubePlayerOverlayState();
}

class _RutubePlayerOverlayState extends State<_RutubePlayerOverlay>
    with WidgetsBindingObserver {
  late final WebViewController _controller;
  bool _ready = false;
  bool _playing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    final uri = Uri.parse(_asEmbed(widget.url));
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) setState(() => _ready = true);
          },
          onWebResourceError: (_) {
            if (mounted) setState(() => _ready = true);
          },
        ),
      )
      ..loadRequest(uri, headers: const {'Referer': 'https://rutube.ru'});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      _pause();
    }
    super.didChangeAppLifecycleState(state);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pause();
    super.dispose();
  }

  String _asEmbed(String input) {
    if (input.contains('/play/embed/')) {
      // ensure autoplay disabled
      return input.contains('?') ? '$input&autoStart=false' : '$input?autoStart=false';
    }
    final id = RegExp(r'([a-f0-9]{32})', caseSensitive: false).firstMatch(input)?.group(1);
    final base = id != null ? 'https://rutube.ru/play/embed/$id' : input;
    return base.contains('?') ? '$base&autoStart=false' : '$base?autoStart=false';
  }

  Future<void> _play() async {
    try {
      await _controller.runJavaScript('document.querySelector("video")?.play();');
      if (mounted) setState(() => _playing = true);
    } catch (_) {}
  }

  Future<void> _pause() async {
    try {
      await _controller.runJavaScript('document.querySelector("video")?.pause();');
      if (mounted) setState(() => _playing = false);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 16 / 9,
      child: Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: WebViewWidget(controller: _controller),
          ),
          if (!_playing)
            Positioned.fill(
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 200),
                opacity: _ready ? 1 : 0.6,
                child: Material(
                  color: Colors.black26,
                  child: InkWell(
                    onTap: _ready ? _play : null,
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.92),
                          shape: BoxShape.circle,
                          boxShadow: const [BoxShadow(blurRadius: 12, color: Colors.black26)],
                        ),
                        child: const Icon(Icons.play_arrow, size: 48, color: Color(0xff000E6B)),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// ============== Rutube lazy player with real thumbnail preview ==============
class _RutubeLazyPlayer extends StatefulWidget {
  final String url;
  const _RutubeLazyPlayer({required this.url});

  @override
  State<_RutubeLazyPlayer> createState() => _RutubeLazyPlayerState();
}

class _RutubeLazyPlayerState extends State<_RutubeLazyPlayer>
    with WidgetsBindingObserver {
  bool _loadWebView = false;
  bool _playing = false;
  bool _ready = false;

  late final WebViewController _controller;

  String? _rutubeIdFromUrlLocal(String url) {
    final r1 = RegExp(r'rutube\.ru/(?:video|shorts)/([A-Za-z0-9_-]{16,36})/?');
    final r2 = RegExp(r'rutube\.ru/play/embed/([A-Za-z0-9_-]{16,36})');
    return r1.firstMatch(url)?.group(1) ?? r2.firstMatch(url)?.group(1);
  }

  String _thumbnailUrl(String id) => 'https://pic.rutube.ru/video/$id/thumbnail.jpg';

  String _embedUrl(String id, {bool autoplay = false}) {
    final base = 'https://rutube.ru/play/embed/$id';
    final qp = autoplay ? 'autoStart=true' : 'autoStart=false';
    return '$base?$qp';
  }

  Future<void> _initAndPlay(String id) async {
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) async {
            if (!mounted) return;
            setState(() => _ready = true);
            await _controller.runJavaScript('document.querySelector("video")?.play();');
            if (mounted) setState(() => _playing = true);
          },
        ),
      )
      ..loadRequest(Uri.parse(_embedUrl(id, autoplay: true)),
          headers: const {'Referer': 'https://rutube.ru'});

    setState(() {
      _loadWebView = true;
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) {
      if (_loadWebView) {
        _controller.runJavaScript('document.querySelector("video")?.pause();');
        _playing = false;
      }
    }
    super.didChangeAppLifecycleState(state);
  }

  @override
  Widget build(BuildContext context) {
    final id = _rutubeIdFromUrlLocal(widget.url);
    if (id == null) {
      return _RutubePlayerOverlay(url: widget.url);
    }

    return AspectRatio(
      aspectRatio: 16 / 9,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (!_loadWebView)
              Image.network(
                _thumbnailUrl(id),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: const Color(0xFFe8e8f2)),
                loadingBuilder: (ctx, child, prog) {
                  if (prog == null) return child;
                  return Container(
                    color: const Color(0xFFe8e8f2),
                    child: const Center(child: CircularProgressIndicator()),
                  );
                },
              )
            else
              WebViewWidget(controller: _controller),

            if (!_loadWebView)
              Material(
                color: Colors.black26,
                child: InkWell(
                  onTap: () => _initAndPlay(id),
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.92),
                        shape: BoxShape.circle,
                        boxShadow: const [BoxShadow(blurRadius: 12, color: Colors.black26)],
                      ),
                      child:
                      const Icon(Icons.play_arrow, size: 48, color: Color(0xff000E6B)),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
