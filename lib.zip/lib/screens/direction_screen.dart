import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/adapters.dart';

import '../models/region.dart';
import '../screens/region_detail_screen.dart';
import '../widgets/root_shell_host.dart';

// Светло-бежевый фон для всей страницы
const _kBeige = Color(0xFFF5F5DC);

class DirectionsScreen extends StatefulWidget {
  const DirectionsScreen({Key? key}) : super(key: key);

  @override
  State<DirectionsScreen> createState() => _DirectionsScreenState();
}

class _DirectionsScreenState extends State<DirectionsScreen> {
  late final Box<Region> _regionsBox;

  @override
  void initState() {
    super.initState();
    _regionsBox = Hive.box<Region>('regions');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBeige, // ← бежевый под всем экраном
      appBar: AppBar(
        title: const Text('Направления'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Container(
        color: _kBeige, // ← гарантируем бежевый под контентом
        child: SafeArea(
          bottom: true,
          child: ValueListenableBuilder(
            valueListenable: _regionsBox.listenable(),
            builder: (context, Box<Region> box, _) {
              final regions = box.values.toList();
              if (regions.isEmpty) {
                return const _EmptyStub();
              }
              return ListView.separated(
                padding: EdgeInsets.fromLTRB(16, 16, 16, RootShellHost.bottomGap),
                itemCount: regions.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final region = regions[index];
                  return _RegionCard(
                    region: region,
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => RegionDetailScreen(region: region),
                        ),
                      );
                    },
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}

class _RegionCard extends StatelessWidget {
  const _RegionCard({
    Key? key,
    required this.region,
    required this.onTap,
  }) : super(key: key);

  final Region region;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final imageWidget = _buildRegionImage(region.imageUrl);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Ink(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor, // карточка остаётся контрастной
          borderRadius: BorderRadius.circular(16),
          boxShadow: const [
            BoxShadow(
              blurRadius: 10,
              offset: Offset(0, 4),
              color: Color(0x14000000),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: imageWidget,
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
              child: Text(
                region.name,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            if ((region.description).trim().isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                child: Text(
                  region.description,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildRegionImage(String imageUrl) {
    if (imageUrl.isEmpty) {
      return const _ImagePlaceholder();
    }
    final isNetwork = imageUrl.startsWith('http');
    if (isNetwork) {
      return Image.network(
        imageUrl,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => const _ImagePlaceholder(),
      );
    } else {
      return Image.asset(
        imageUrl,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => const _ImagePlaceholder(),
      );
    }
  }
}

class _ImagePlaceholder extends StatelessWidget {
  const _ImagePlaceholder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).colorScheme.surfaceVariant,
      child: Center(
        child: Icon(
          Icons.landscape_outlined,
          size: 48,
          color: Theme.of(context).colorScheme.outline,
        ),
      ),
    );
  }
}

class _EmptyStub extends StatelessWidget {
  const _EmptyStub({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          'Пока нет регионов. Добавьте их в админ-панели.',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodyLarge,
        ),
      ),
    );
  }
}
