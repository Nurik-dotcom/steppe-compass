
import 'package:flutter/material.dart';
import '../models/place.dart';
import '../screens/place_detail_screen.dart';
import '../services/likes_service.dart';

class KtPlaceCard extends StatelessWidget {
  final Place place;
  const KtPlaceCard({Key? key, required this.place}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final likesRemote = LikesServiceRemote();
    final String? img = (place.imageUrl.isNotEmpty) ? place.imageUrl.first : null;

    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => PlaceDetailScreen(place: place)),
        );
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            
            AspectRatio(
              aspectRatio: 16 / 10,
              child: img == null
                  ? Container(
                color: Colors.grey.shade300,
                child: const Center(child: Icon(Icons.image_not_supported)),
              )
                  : (img.startsWith('http')
                  ? Image.network(img, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: Colors.grey.shade300,
                  child: const Center(child: Icon(Icons.broken_image)),
                ),
              )
                  : Image.asset(img, fit: BoxFit.cover)),
            ),

            
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      place.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Row(
                    children: [
                      const Icon(Icons.favorite, size: 16, color: Colors.redAccent),
                      const SizedBox(width: 4),
                      StreamBuilder<int>(
                        stream: likesRemote.likeCountStream(place.id),
                        builder: (_, snap) => Text('${snap.data ?? 0}'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
